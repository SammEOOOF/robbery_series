lib.locale()

RegisterNetEvent('kaliber_ghostgun_robbery:MainHandler')
AddEventHandler('kaliber_ghostgun_robbery:MainHandler', function()
    exports.ox_doorlock:setDoorState(1, 1)
end)

ESX.RegisterServerCallback('kaliber_ghostgun_robbery:CheckCooldown', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    MySQL.Async.fetchAll('SELECT getting_robbed, cooldown_expire FROM samme_jobs_robberies WHERE place_name = @place_name', {
        ['@place_name'] = 'ghostgun_factory'
    }, function(result)
        if result[1] then
            local currentTime = os.time()
            local cooldownExpire = 0

            if result[1].cooldown_expire then
                if type(result[1].cooldown_expire) == "number" then
                    cooldownExpire = result[1].cooldown_expire > 9999999999 and result[1].cooldown_expire / 1000 or result[1].cooldown_expire
                elseif type(result[1].cooldown_expire) == "string" then
                    local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"
                    local year, month, day, hour, min, sec = result[1].cooldown_expire:match(pattern)
                    if year then
                        cooldownExpire = os.time({year=year, month=month, day=day, hour=hour, min=min, sec=sec})
                    else
                        print("Error: Unable to parse cooldown_expire date string")
                    end
                else
                    print("Error: Unexpected cooldown_expire type")
                end
            end

            print("Current time:", currentTime, "Cooldown expire:", cooldownExpire)

            if currentTime >= cooldownExpire then
                MySQL.Async.execute('UPDATE samme_jobs_robberies SET cooldown_expire = NULL WHERE place_name = @place_name', {
                    ['@place_name'] = 'ghostgun_factory'
                })
                
                if result[1].getting_robbed == 1 then
                    cb(false, 'being_robbed')
                else
                    cb(true, 'can_be_robbed')
                end
            else
                if result[1].getting_robbed == 1 then
                    cb(false, 'being_robbed')
                else
                    cb(false, 'not_available')
                end
            end
        else
            print("Error: 'ghostgun_factory' not found in the database.")
            cb(false, 'error')
        end
    end)
end)

ESX.RegisterServerCallback('kaliber_ghostgun_robbery:OpenGarageDoor', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    MySQL.Async.execute('UPDATE samme_jobs_robberies SET getting_robbed = 1 WHERE place_name = @place_name', {
        ['@place_name'] = 'ghostgun_factory'
    }, function(rowsChanged)
        if rowsChanged > 0 then
            exports.ox_doorlock:setDoorState(1, 0)
            cb(true)
            print(("Player %s (ID: %s) has started robbing the ghostgun factory."):format(xPlayer.name, xPlayer.source))
        else
            cb(false)
            print(("Failed to update robbery status for ghostgun factory. Attempted by Player %s (ID: %s)"):format(xPlayer.name, xPlayer.source))
        end
    end)
end)

local function StartCooldown()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if xPlayer ~= nil then
        local cooldownTime = Config.RobberyCooldownTime
        local cooldownExpire = os.time() + (cooldownTime / 1000)

        MySQL.Async.execute('UPDATE samme_jobs_robberies SET getting_robbed = 0, cooldown_expire = FROM_UNIXTIME(@cooldown_expire) WHERE place_name = @place_name', {
            ['@place_name'] = 'ghostgun_factory',
            ['@cooldown_expire'] = cooldownExpire
        }, function(rowsChanged)
            if rowsChanged > 0 then
                print(("Cooldown started for ghostgun factory. Expires at %s. Set by Player %s (ID: %s)"):format(os.date("%Y-%m-%d %H:%M:%S", cooldownExpire), xPlayer.name, xPlayer.source))
            else
                print(("Failed to start cooldown for ghostgun factory. Attempted by Player %s (ID: %s)"):format(xPlayer.name, xPlayer.source))
            end
        end)
    else
        print('xPlayer not initialized!')
    end
end

RegisterNetEvent('kaliber_ghostgun_robbery:CollectLoot')
AddEventHandler('kaliber_ghostgun_robbery:CollectLoot', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if xPlayer ~= nil then
        local lootGiven = false
        
        for item, data in pairs(Config.LootPool) do
            local chance = data.Chance
            if math.random() <= chance then
                local amount = type(data.Amount) == "function" and data.Amount() or data.Amount
                
                if xPlayer.canCarryItem(item, amount) then
                    xPlayer.addInventoryItem(item, amount)
                    TriggerClientEvent('esx:showNotification', src, locale('found_item'):format(amount, item))
                    lootGiven = true
                    TriggerClientEvent('kaliber_ghostgun_robbery:StartTimer', src)
                    StartCooldown()
                    break
                end
            end
        end
        
        if not lootGiven then
            TriggerClientEvent('esx:showNotification', src, locale('found_nothing'))
        end
    else
        print('xPlayer not initialized for source: ' .. src)
    end
end)