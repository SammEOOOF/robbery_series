CREATE TABLE IF NOT EXISTS `samme_jobs_robberies` (
  `place_name` varchar(100) NOT NULL,
  `getting_robbed` int(1) NOT NULL,
  `cooldown_expire` datetime,
) ENGINE=InnoDB;

INSERT INTO `samme_jobs_robberies` (`place_name`, `getting_robbed`, `cooldown_expire`) VALUES
('ghostgun_factory', 0, NULL);