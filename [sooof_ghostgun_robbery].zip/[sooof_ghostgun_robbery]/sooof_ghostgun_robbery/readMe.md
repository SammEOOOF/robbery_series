Hello there! Thank you for downloading the first script of the SOOOF_ROBBERIES series!

Yes this is escrowed due to the extensions, but don't worry! The script is still 100% free because
you don't need the extensions for the script! Be sure to read the license and have fun when using
the script!

For any support, join my discord
https://discord.gg/W4Nr4KMYrH

Github
https://github.com/sammeooof

Once again, thank you!