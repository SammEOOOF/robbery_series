Config = {} or Config

-- / SOOOF Library is needed for these! / --
Config.UseSammEOOOFSkillSystem = false
Config.UseSammEOOOFNotify      = false -- / If false you need to set the Config.Notify to either 'esx' or 'ox_lib'
Config.SkillNeeded   = 'lockpicking'
Config.MinSkillLevel = 3

-- / Script Backend Settings / --
Config.Notify = 'esx' -- / Either 'esx' or 'ox_lib'

-- / Script Game Settings / --
Config.ElectricalBoxProp     = `prop_elecbox_02a`
Config.ElectricalBoxLocation = vec4(-324.36401367188, -1346.4876708984, 30.149596710205, 90.00000000)
Config.ItemNeeded            = 'lockpick' -- / Either 'item_name' or false / --

Config.DoorLockTimer         = math.random(20000, 60000)
Config.RobberyCooldownTime   = math.random(30 * 60000, 60 * 60000) -- / Because its * 60000 its in minutes! / --

-- / Prop Spawn Locations / --
Config.BoxSearchTime = math.random(30000, 45000)

Config.RobberyProp = `prop_box_ammo03a`
Config.PropSpawnLocations = {
    vec4(-309.8341, -1357.9119, 31.3937, 29.2117),
    vec4(-316.9435, -1357.6409, 32.1903, 170.4690),
    vec4(-322.7192, -1357.1641, 32.5309, 109.4036),
    vec4(-319.1306, -1346.6737, 33.0681, 169.6891),
    vec4(-313.9287, -1346.4733, 32.6524, 1.4988),
    vec4(-307.2798, -1347.8792, 31.8407, 6.1329),
    vec4(-305.8467, -1344.2646, 31.3937, 357.9154),
    -- / Add more locations if you'd like! / --
}

Config.LootPool = {
    ['scrapmetal'] = {
        Chance = 0.6,
        Amount = math.random(6, 11),
    },
    ['phone'] = {
        Chance = 0.8,
        Amount = math.random(1, 2),
    },
    ['black_money'] = {
        Chance = 0.6,
        Amount = math.random(147, 367),
    },
    ['lockpick'] = {
        Chance = 0.6,
        Amount = 1,
    },
    ['armour'] = {
        Chance = 0.3,
        Amount = math.random(1, 3),
    },
    -- / Add more if you'd like! / --
}