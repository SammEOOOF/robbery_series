fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'SammEOOOF'
description 'Ghost Gun Robbery, minigames, lockpicking, skill integrations etc!'
version '1.0.0'

client_scripts {
    'client/cl_main.lua',
}

server_scripts {
    'server/sv_main.lua',
    '@oxmysql/lib/MySQL.lua',
}

shared_scripts {
    'config.lua',
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
}

files {
    'locales/*.json',
}

escrow_ignore {
    'config.lua',
    'insert.sql',
    'locales/*.json',
}