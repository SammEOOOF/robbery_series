if not ESX then return end
if not lib then return end
lib.locale()
KALIBER = exports['kaliber_exports']

local electricalBoxObject = nil

local function ShowNotification(message, title)
    if Config.UseSammEOOOFNotify then
        KALIBER.ShowNotification('kaliber_ghostgun_robbery', title or '???', message, 3500, 'error', 'fas fa-circle-question')
    elseif Config.Notify == 'esx' then
        ESX.ShowNotification(message)
    elseif Config.Notify == 'ox_lib' then
        lib.notify({
            title = title or '???',
            description = message,
            type = 'error'
        })
    else
        print("Notification system not properly configured in Config.lua")
    end
end

local function PerformRobbery()
    return lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 1}, 'easy'}, {'1', '2', '3', '4'})
end

local function CheckSkill(callback)
    if not Config.UseSammEOOOFSkillSystem then
        return callback(true)
    end

    exports['kaliber_basic']:GetSkillLevel(Config.SkillNeeded, function(skill, skillLevel)
        if skillLevel >= Config.MinSkillLevel then
            callback(true)
        else
            ShowNotification(locale('no_skill'))
            callback(false)
        end
    end)
end


local function ItemCheck()
    if not Config.ItemNeeded then return true end

    local hasItem = exports.ox_inventory:Search('count', Config.ItemNeeded) > 0
    if not hasItem then
        ShowNotification(locale('missing_equipment'))
        return false
    else
        return true
    end
end

local function SpawnLoot()
    local spawnPoint = Config.PropSpawnLocations[math.random(#Config.PropSpawnLocations)]
    local obj = CreateObject(Config.RobberyProp, spawnPoint.x, spawnPoint.y, spawnPoint.z, true, false, false)
    SetEntityHeading(obj, spawnPoint.w)
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)

    exports.ox_target:addLocalEntity(obj, {
        {
            name = 'collect_loot',
            icon = 'fas fa-hand-paper',
            label = locale('open_box'),
            distance = 1.2,
            onSelect = function()
                if lib.progressCircle({
                    duration = Config.BoxSearchTime,
                    label = locale('prying_open_box'),
                    useWhileDead = false,
                    canCancel = true,
                    disable = {
                        car = true,
                        move = false,
                    },
                    anim = {
                        dict = 'amb@prop_human_bum_bin@base',
                        clip = 'base'
                    },
                }) 
                then 
                    TriggerServerEvent('kaliber_ghostgun_robbery:CollectLoot')
                    DeleteEntity(obj)
                else 
                    ShowNotification(locale('action_cancelled'), 'Server')
                end
            end
        }
    })
end

local function AttemptRobbery()
    if not ItemCheck() then return end

    if PerformRobbery() then
        if lib.progressCircle({
            duration = 20000,
            label = locale('rewiring'),
            position = 'bottom',
            useWhileDead = false,
            canCancel = true,
            disable = {
                car = true,
                move = true,
            },
            anim = {
                dict = 'amb@prop_human_parking_meter@female@base',
                clip = 'base_female',
            },
        })
        then 
            ESX.TriggerServerCallback('kaliber_ghostgun_robbery:OpenGarageDoor', function(success)
                if success then
                    SpawnLoot()
                    ShowNotification(locale('robbery_success'), locale('success'))
                else
                    print('något gick fel!')
                end
            end)
        else 
            ShowNotification(locale('action_cancelled'), 'Server')
        end
    else
        ShowNotification(locale('robbery_failure'), locale('failed'))
    end
end

function Main()
    TriggerServerEvent('kaliber_ghostgun_robbery:MainHandler')
    
    local boxlocation = Config.ElectricalBoxLocation
    local modelHash = Config.ElectricalBoxProp

    lib.requestModel(modelHash)

    electricalBoxObject = CreateObject(modelHash, boxlocation.x, boxlocation.y, boxlocation.z, true)
    FreezeEntityPosition(electricalBoxObject, true)
    SetEntityHeading(electricalBoxObject, boxlocation.w)
    SetModelAsNoLongerNeeded(modelHash)

    exports.ox_target:addLocalEntity(electricalBoxObject, {
        {
            coords = electricalBoxObject,
            size = vec3(2, 2, 2),
            rotation = 45,
            label = locale('interaction_label'),
            icon = 'fas fa-charging-station',
            distance = 1.2,
            onSelect = function(data)
                ESX.TriggerServerCallback('kaliber_ghostgun_robbery:CheckCooldown', function(canRob, reason)
                    if canRob then
                        CheckSkill(function(skillCheckPassed)
                            if skillCheckPassed then
                                AttemptRobbery()
                            end
                        end)
                    else
                        if reason == 'being_robbed' then
                            ShowNotification(locale('robbery_in_progress'), 'Server')
                        elseif reason == 'not_available' then
                            ShowNotification(locale('cannot_rob_now'), 'Server')
                        elseif reason == 'error' then
                            ShowNotification(locale('error_occurred'), 'Server')
                        elseif reason == 'can_be_robbed' then
                            ShowNotification(locale('box_destroyed'), 'Server')
                        end
                    end
                end)
            end
        }
    })
end

RegisterNetEvent('kaliber_ghostgun_robbery:StartTimer')
AddEventHandler('kaliber_ghostgun_robbery:StartTimer', function()
    ShowNotification(locale('escape_warning'), locale('unknown'))
    Citizen.Wait(Config.DoorLockTimer)
    TriggerServerEvent('kaliber_ghostgun_robbery:MainHandler')
end)

local function RemoveElectricalBox()
    if electricalBoxObject and DoesEntityExist(electricalBoxObject) then
        exports.ox_target:removeLocalEntity(electricalBoxObject)
        DeleteEntity(electricalBoxObject)
        electricalBoxObject = nil
    end
end

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    Main()
end)

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    RemoveElectricalBox()
end)